package model.cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Free extends Cell {

    public static final char freeChar = '.' ;

    public Free(){
        super(freeChar) ;
    }
}
