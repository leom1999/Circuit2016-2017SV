package model.cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Line extends Cell{

    public Line(char c){
        super(c) ;
    }

}
