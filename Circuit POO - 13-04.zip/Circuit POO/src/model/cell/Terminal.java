package model.cell;

import view.cell.CellView;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Terminal extends Cell {

    public int terminalChar ;

    public Terminal(char c) {
        super(c);
        terminalChar = c ;
    }
    
}
