package model.cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Dir {
    public final int deltaLin;
    public final int deltaCol;

    public Dir(int deltaLin, int deltaCol) {
        this.deltaLin = deltaLin;
        this.deltaCol = deltaCol;
    }

    public static Dir[] values() {
        Dir[] arr = {new Dir(0, 1), new Dir(1, 0),
                    new Dir(0, -1), new Dir(-1, 0)
        };
        return arr;
    }
}