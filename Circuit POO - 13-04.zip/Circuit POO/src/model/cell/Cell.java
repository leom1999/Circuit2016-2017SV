package model.cell;

import view.cell.CellView;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Cell {

    public static Cell cell = null;
    public char cellChar;

    public Cell(char c){
        cellChar = c ;
    }

    public static Cell newInstance(char c) {
        if (c == '.') cell = new Free();
        else if (c == '-' || c == '|') cell = new Line(c);
        else if (c>='A' && c<='F') cell = new Terminal(c);
        return cell;
    }

    public boolean fromString(String word) {
        return true;
    }

    public static int getColor(char c) {
        return c - 'A' ;
    }
}
