package model;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Position {

    private static int line ;
    private static int col  ;

    public Position(int line, int col){
        line = line;
        col = col;
    }
}
