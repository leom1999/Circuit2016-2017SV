package view;

import isel.leic.pg.Console;
import model.Circuit;
import model.Loader;
import model.Position;
import view.cell.CellView;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Panel {

    public static int testI;
    public static int testJ;

    public boolean question(String quest){
        return false ;
    }

    public void message(String msg){

    }

    public void close() {
        Console.close();
    }

    public void open(Circuit model) {
        Console.open("Circuit", model.height*3+1,model.width*3);
        for (int i = 0; i < model.height ; i++) {
            for (int j = 0; j < model.width; j++) {
                testI = i;
                testJ = j;
                CellView.newInstance(model.circuitAR[i][j]);
            }
        }
    }

    public void repaintTime() {

    }

    public Position getModelPosition(int line, int col){
        return null;
    }

    public void paint(Position position, boolean b) {
    }

    public void repaint() {

    }
}
