package view.cell;

import isel.leic.pg.Console;
import model.cell.Cell;
import view.Panel;

/**
 * Created by lmartins on 30-03-2017.
 */
public class LineView extends CellView {
    public LineView(Cell cell) {
        super(cell);
        paint(Panel.testI,Panel.testJ,false,' ');
        if (cell.cellChar=='-'){
            posFromCircToPan(Panel.testI,Panel.testJ);
            for (int i = 0; i < CELL_SIDE ; i++) {
                Console.cursor(coord[0],coord[1]-1+i);
                write(' ', Console.GRAY);
            }
        }
        else if (cell.cellChar=='|'){
            posFromCircToPan(Panel.testI,Panel.testJ);
            for (int i = 0; i < CELL_SIDE ; i++) {
                Console.cursor(coord[0]-1+i,coord[1]);
                write(' ', Console.GRAY);
            }
        }
    }
}
