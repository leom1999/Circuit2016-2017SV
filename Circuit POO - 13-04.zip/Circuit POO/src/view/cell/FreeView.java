package view.cell;

import isel.leic.pg.Console;
import model.cell.Cell;
import view.Panel;

/**
 * Created by lmartins on 30-03-2017.
 */
public class FreeView extends CellView {
    public FreeView(Cell cell) {
        super(cell);
        paint(Panel.testI,Panel.testJ,false,' ');
        posFromCircToPan(Panel.testI,Panel.testJ);
        Console.cursor(coord[0],coord[1]);
        write(' ', Console.GRAY);
    }
}
