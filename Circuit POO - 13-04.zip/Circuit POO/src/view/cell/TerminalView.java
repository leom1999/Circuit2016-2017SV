package view.cell;

import model.cell.Cell;
import model.cell.Terminal;
import view.Panel;

/**
 * Created by lmartins on 30-03-2017.
 */
public class TerminalView extends CellView {
    public TerminalView(Cell cell) {
        super(cell);
        CellView.bkColor = getColor(cell.cellChar) ;
        paint(Panel.testI,Panel.testJ,false,'O');
    }
}
