package model.cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Terminal extends Cell {

    public Terminal(char c) {
        this.cellChar = c ;
    }

}
