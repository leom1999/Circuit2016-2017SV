package model.cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Cell {

    public static Cell cell;
    public static char cellChar;

    public static Cell newInstance(char c) {
        if (c == '.') cell = new Free();
        if (c == '-') cell = new Line();
        if (c>='A' && c<='F') cell = new Terminal(c);
        return cell;
    }

    public boolean fromString(String word) {
        return false;
    }

    public int getColor() {
        return 1;
    }
}
