package model;

import model.cell.Cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Circuit {

    public static int height;
    public static int width;


    public Circuit(int height, int width) {
        this.height = height;
        this.width = width;
    }

    public boolean isOver() {
        return false;
    }

    public boolean drag(Position f, Position pos) {
        return false;
    }

    public boolean unlink(Position pos) {
        return false;
    }

    public void putCell(int l, int i, Cell cell) {
    }
}
