package model;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Position {

    private static int line ;
    private static int col  ;



}
