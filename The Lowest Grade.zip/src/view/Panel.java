package view;

import isel.leic.pg.Console;
import model.Circuit;
import model.Position;

/**
 * Created by lmartins on 30-03-2017.
 */
public class Panel {

    public boolean question(String quest){
        return false ;
    }

    public void message(String msg){

    }

    public void close() {
        Console.close();
    }

    public void open(Circuit model) {
        Console.open("Circuit",20,20);
    }

    public void repaintTime() {

    }

    public Position getModelPosition(int line, int col) {
        return null;
    }

    public void paint(Position position, boolean b) {

    }

    public void repaint() {

    }
}
