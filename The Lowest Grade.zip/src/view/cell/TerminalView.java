package view.cell;

import model.cell.Cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class TerminalView extends CellView {
    public TerminalView(Cell cell) {
        super(cell);
    }
}
