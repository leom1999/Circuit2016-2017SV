package view.cell;

import model.cell.Cell;

/**
 * Created by lmartins on 30-03-2017.
 */
public class FreeView extends CellView {
    public FreeView(Cell cell) {
        super(cell);
    }
}
